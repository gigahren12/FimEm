a = 0
b = [a.to_bytes(1, 'little')] * 2048
with open("harddisk", 'wb') as f:
    for by in b:
        f.write(by) 