from PIL import Image
import os

def binary_to_image(binary_file_path, output_image_path):
    # Открываем бинарный файл и читаем его содержимое
    with open(binary_file_path, 'rb') as binary_file:
        binary_data = binary_file.read()

    # Определяем размер изображения (ширина и высота)
    pixel_count = len(binary_data) // 3
    width = int(pixel_count ** 0.5)
    height = pixel_count // width

    # Убедимся, что размер изображения кратен 3
    if len(binary_data) % 3 != 0:
        binary_data = binary_data[:height * width * 3]

    # Создаем новое изображение
    image = Image.new('RGB', (width, height))

    # Заполняем изображение пикселями
    image_data = []
    for i in range(0, len(binary_data), 3):
        r = binary_data[i]
        g = binary_data[i + 1]
        b = binary_data[i + 2]
        image_data.append((r, g, b))

    image.putdata(image_data)
    
    # Сохраняем изображение
    image.save(output_image_path)
    print(f"Изображение сохранено как {output_image_path}")

# Пример использования
binary_file = 'fimOS.asm'  # Замените на путь к вашему бинарному файлу
output_image = 'output.png'  # Замените на желаемое имя выходного изображения
binary_to_image(binary_file, output_image)
