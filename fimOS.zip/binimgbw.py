from PIL import Image

def binary_to_grayscale_image(binary_file_path, output_image_path):
    # Открываем бинарный файл и читаем его содержимое
    with open(binary_file_path, 'rb') as binary_file:
        binary_data = binary_file.read()

    # Определяем размер изображения (ширина и высота)
    pixel_count = len(binary_data)
    width = int(pixel_count ** 0.5)
    height = pixel_count // width

    # Создаем новое черно-белое изображение
    image = Image.new('L', (width, height))

    # Заполняем изображение пикселями
    image_data = []
    for byte in binary_data:
        image_data.append(byte)  # Каждый байт соответствует уровню яркости

    # Убедимся, что размер данных соответствует размеру изображения
    if len(image_data) < width * height:
        image_data.extend([0] * (width * height - len(image_data)))  # Заполняем оставшиеся пиксели черным

    image.putdata(image_data[:width * height])  # Ограничиваем данные до нужного размера
    
    # Сохраняем изображение
    image.save(output_image_path)
    print(f"Изображение сохранено как {output_image_path}")

# Пример использования
binary_file = 'harddisk'  # Замените на путь к вашему бинарному файлу
output_image = 'output.png'  # Замените на желаемое имя выходного изображения
binary_to_grayscale_image(binary_file, output_image)
