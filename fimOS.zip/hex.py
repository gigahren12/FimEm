def hex_viewer(file_path):
    try:
        with open(file_path, 'rb') as f:
            offset = 0
            while True:
                # Читаем 10 байт
                bytes_read = f.read(10)
                if not bytes_read:
                    break  # Конец файла

                # Форматируем адрес и байты
                hex_address = f"{offset:08}"
                hex_bytes = ' '.join(f"{byte:02x}" for byte in bytes_read).upper()
                print(f"{hex_address}: {hex_bytes}")

                offset += 10  # Увеличиваем смещение на 10

    except FileNotFoundError:
        print(f"Файл '{file_path}' не найден.")
    except Exception as e:
        print(f"Произошла ошибка: {e}")

if __name__ == "__main__":
    file_path = input("Введите путь к файлу: ")
    if file_path != '':
        hex_viewer(file_path)
