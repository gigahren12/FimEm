import configparser
import datetime
import time
from assembler.asm import Translator
class Manager:
    def __init__(self):
        self.cfg = configparser.ConfigParser()
        self.assem = Translator()
        self.path = ""
        
    def read_config(self, path):
        conf = self.cfg.read(path)
        print(path)
        self.name = conf["general"]["name"]
        self.ver = conf["general"]["version"]
        self.description = conf["general"]["description"]
        self.main = conf["build"]["main"]
    
    def open_project(self, path):
        self.path = path
        self.read_config(self.path + "/project_config.ini")
     
     
    def build(self, path):
        with open(path + '/main.asm' , 'r') as f:
            source = [row.split(';')[0].strip() for row in f if row.strip() and not row.startswith(';')]
            source = [s.split(' ') for s in source]

        current_date = datetime.datetime.now()
        current_date_string = current_date.strftime('%d%m%y%H%M%S')
       
        start = time.time()
        bin = self.assem.assembly(source, path)
        end = time.time()
        length = 0
        with open(f"{path}/{path}-BUILD-{current_date_string}", 'wb') as f:
            for b in bin:
                for byte in b:
                    f.write(byte)
                    length += 1
                   
        print(f"The project was successfully builded in {str(int((end - start) * 1000))} milliseconds with a total file weight of {length} bytes.")