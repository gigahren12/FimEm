import hashlib
import os

def calculate_sha256(file_path):
    sha256_hash = hashlib.sha256()
    with open(file_path, 'rb') as file:
        for chunk in iter(lambda: file.read(4096), b""):
            sha256_hash.update(chunk)
    return sha256_hash.hexdigest()

def list_files_and_calculate_hashes():
    current_dir = os.getcwd()
    files = os.listdir(current_dir)

    for file_name in files:
        file_path = os.path.join(current_dir, file_name)
        if os.path.isfile(file_path):  # Проверяем, что это файл, а не папка
            sha256_hash = calculate_sha256(file_path)
            print(f"{file_name}: {sha256_hash}")

list_files_and_calculate_hashes()